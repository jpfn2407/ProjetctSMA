#!/bin/sh

java -jar MeetingScheduler.jar -nomtp -gui "Tizio:demo.MeetingScheduler.MeetingSchedulerAgent" "Caio:demo.MeetingScheduler.MeetingSchedulerAgent"
